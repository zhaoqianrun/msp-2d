﻿MSP-2D 鈥斺€?Meows Space Project 2D
================================

鎬庝箞鐜?------

1. 瑁?Python锛堝鏋滅數鑴戣繕娌¤锛夛細https://www.python.org/downloads/
   瀹夎鏃惰寰楀嬀閫夈€孉dd Python to PATH銆?
2. 鎵撳紑鍛戒护琛岋紙Windows 鎸?Win+R锛岃緭鍏?cmd 鍥炶溅锛?
3. 杩涘叆杩欎釜鏂囦欢澶癸紝杩愯锛?       python server.py

4. 娴忚鍣ㄤ細鑷姩鎵撳紑锛屾垨鑰呮墜鍔ㄨ闂細
       http://localhost:8080/play-main.html

5. 鍚屼竴涓?WiFi 涓嬶紝鎵嬫満涔熻兘鐜╋細
       http://浣犵殑鐢佃剳IP:8080/play-main.html

   鐢佃剳IP 鍦?server.py 鍚姩鏃朵細鎵撳嵃鍑烘潵銆?
鎿嶄綔
----

   E        鐐圭伀 / 鍏虫満
   A D      宸﹁浆 / 鍙宠浆
   鈫?鈫?     娌归棬锛堟寜浣?Shift 寰皟锛?   [ ]      缂╂斁锛堟垨婊氳疆锛?   绌烘牸     鍒嗙骇 / 鍒囨柇涓嬩竴绾?   P        灞曞紑 / 鍒囨柇闄嶈惤浼?   . ,      鍔犻€?/ 鍑忛€熸椂闂?   V        鍒囨崲鑸ぉ鍣?   S L      瀛樻。 / 璇绘。
   C        鎴愬氨鍒楄〃
   R        閲嶇疆杩欎竴瓒?   M        鑳屾櫙闊充箰
   ESC      鏆傚仠鑿滃崟

鍥㈤槦
----

   NotNormal
   B绔欙細https://space.bilibili.com/258037329
   婧愮爜锛歨ttps://github.com/zhaoqianrun/msp-2d